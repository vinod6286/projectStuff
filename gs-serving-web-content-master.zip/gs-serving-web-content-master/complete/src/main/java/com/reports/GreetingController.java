package com.reports;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.reports.widget.CSVReader;
import com.reports.widget.WidgetVO;

@Controller
public class GreetingController {

	@GetMapping("/greeting")
	public String greeting(@RequestParam(name = "name", required = false, defaultValue = "World") String name,
			Model model) {
		CSVReader.firstReport();
		// List<WidgetVO> list = CSVReader.loadObjectList(WidgetVO.class,
		// "production.csv");
		model.addAttribute("name", name);
		return "greeting";
	}

	@GetMapping("/reports")
	public String reports(Model model) {
		CSVReader.firstReport();
		Map<String, String> firstReport = new HashMap<String, String>();
		Map<String, String> secondReport = new HashMap<String, String>();
		Map<String, List<WidgetVO>> finalData = CSVReader.finalData();
		Map<String, Integer> max = new HashMap<>();
		Map<String, Integer> min = new HashMap<>();
		for (Map.Entry<String, List<WidgetVO>> entry : finalData.entrySet()) {
			// System.out.println("Key : " + entry.getKey() + " Value : " +
			// entry.getValue());

			int totalweeks = entry.getValue().size() / 7;
			int totalWidgets = 0;
			for (WidgetVO widgetVO : entry.getValue()) {
				totalWidgets += Integer.parseInt(widgetVO.getWidgets());
			}

			String weeklyWidget = "" + totalWidgets / totalweeks;
			firstReport.put(entry.getKey(), weeklyWidget);
			// Employee with the highest widget average
			String higestWidget = "" + totalWidgets / finalData.size();
			secondReport.put(entry.getKey(), higestWidget);

			int weeklySum = 0;
			int k = 0;

			List<Integer> l = new ArrayList<Integer>();
			for (WidgetVO widgetVO : entry.getValue()) {
				weeklySum += Integer.parseInt(widgetVO.getWidgets());
				if (k == 7) {

					l.add(weeklySum);
					k = 0;
				}

				k++;

			}
			Collections.sort(l);
			min.put(entry.getKey(), l.get(0));
			max.put(entry.getKey(), l.get(l.size() - 1));

		}
		int maxvalue = 0;
		int minvalue = 0;
		for (Map.Entry<String, Integer> entry : max.entrySet()) {
			maxvalue += entry.getValue();
		}
		for (Map.Entry<String, Integer> entry : min.entrySet()) {
			minvalue += entry.getValue();
		}
		Map<String, String> secondReport1 = secondReport.entrySet().stream()
				.sorted(Map.Entry.comparingByValue(Comparator.reverseOrder())).collect(Collectors.toMap(
						Map.Entry::getKey, Map.Entry::getValue, (oldValue, newValue) -> oldValue, LinkedHashMap::new));
		// System.out.println(result);
		// System.out.println(result.get(0));
		Map<String, String> thirdReport = secondReport.entrySet().stream()
				.sorted(Map.Entry.comparingByValue(Comparator.naturalOrder())).collect(Collectors.toMap(
						Map.Entry::getKey, Map.Entry::getValue, (oldValue, newValue) -> oldValue, LinkedHashMap::new));
		// System.out.println(result);
		// System.out.println(result.get(0));
		System.out.println(secondReport.toString());
		// List<WidgetVO> list = CSVReader.loadObjectList(WidgetVO.class,
		// "production.csv");
		model.addAttribute("firstReport", firstReport);
		model.addAttribute("secondReport", secondReport1);
		model.addAttribute("thirdReport", thirdReport);
		model.addAttribute("fouthReport", maxvalue / 5);
		model.addAttribute("fifthReport", minvalue / 5);

		return "reports";
	}

}
