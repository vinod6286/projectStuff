/**
 * 
 */
package com.reports.widget;

 public class WidgetVO {
	
	/**
	 * @param employeeNumber
	 * @param date
	 * @param widgets
	 */
	public WidgetVO(String employeeNumber, String date, String widgets) {
		super();
		this.employeeNumber = employeeNumber;
		this.date = date;
		this.widgets = widgets;
	}
	private String employeeNumber;
	private String date;
	private String widgets;
	/**
	 * @return the employeeNumber
	 */
	public String getEmployeeNumber() {
		return employeeNumber;
	}
	/**
	 * @param employeeNumber the employeeNumber to set
	 */
	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}
	/**
	 * @return the widgets
	 */
	public String getWidgets() {
		return widgets;
	}
	/**
	 * @param widgets the widgets to set
	 */
	public void setWidgets(String widgets) {
		this.widgets = widgets;
	}
	

}
