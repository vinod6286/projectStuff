/**
 * 
 */
package com.reports.widget;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvParser;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;


public class CSVReader {
	
	@SuppressWarnings("deprecation")
	public static List<String[]> loadManyToManyRelationship(String fileName) {
	    try {
	        CsvMapper mapper = new CsvMapper();
	        CsvSchema bootstrapSchema = CsvSchema.emptySchema().withSkipFirstDataRow(true);
	        mapper.enable(CsvParser.Feature.WRAP_AS_ARRAY);
	        File file = new ClassPathResource(fileName).getFile();
	        MappingIterator<String[]> readValues = mapper.reader(String[].class).with(bootstrapSchema).readValues(file);
	        return readValues.readAll();
	    } catch (Exception e) {
	       // logger.error("Error occurred while loading many to many relationship from file = " + fileName, e);
	        return Collections.emptyList();
	    }
	}
	
	public static Map<String,List<WidgetVO>> finalData() {
		Map<String,List<WidgetVO>> map= new HashMap<>();
		for(String[] data : loadManyToManyRelationship("production.csv")) {
			List<WidgetVO> list = map.get(data[0]);
			if(list == null) {
				list = new ArrayList<>();
			}
			list.add(new WidgetVO(data[0].trim(),data[1].trim(),data[2].trim()));
			map.put(data[0], list);
		}
		return map;
	}
	
	//Average widgets per employee by week
	public static void firstReport() {
		Map<String,String>  firstReport = new HashMap<String,String>();
		Map<String,String>  secondReport = new HashMap<String,String>();
		Map<String,List<WidgetVO>> finalData = finalData();
		Map<String,Integer> max = new HashMap<>();
		Map<String,Integer> min = new HashMap<>();
		for (Map.Entry<String, List<WidgetVO>> entry : finalData.entrySet()) {
			//System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());
			int[] weekArray = new int[53];
			int weeklySum = 0 ;
			int k = 0 ;
			
			int weekCount =0;
			List<Integer> l = new ArrayList<Integer>();
			 for(WidgetVO widgetVO : entry.getValue()) {
          	   weeklySum += Integer.parseInt(widgetVO.getWidgets());
          	 if(k==7) {
          	   weekArray[weekCount] = weeklySum;
          	   l.add(weeklySum);
          	   k=0;
          	   weekCount++;
             }
          	 
          	 k++;
          	   
		 }
		Collections.sort(l);
		max.put(entry.getKey(),l.get(0));
		min.put(entry.getKey(),l.get(l.size()-1));
		
			
			
			int totalweeks = entry.getValue().size()/7;
			int totalWidgets = 0;
			for(WidgetVO widgetVO : entry.getValue()) {
				totalWidgets += Integer.parseInt(widgetVO.getWidgets());
			}
			
			String weeklyWidget = "" + totalWidgets / totalweeks;
			firstReport.put(entry.getKey(), weeklyWidget);
			// Employee with the highest widget average
			String higestWidget = "" + totalWidgets / finalData.size();
			secondReport.put(entry.getKey(), higestWidget);
			
			 
			
		}
		
		Map<String, String> result = secondReport.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                        (oldValue, newValue) -> oldValue, LinkedHashMap::new));
		System.out.println(result);
	 System.out.println(result.get(0));
	 result = secondReport.entrySet().stream() 
                .sorted(Map.Entry.comparingByValue(Comparator.naturalOrder()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                        (oldValue, newValue) -> oldValue, LinkedHashMap::new));
	 System.out.println(result);
	 System.out.println(result.get(0));
		System.out.println(secondReport.toString());
		
		
		//int week [] = finalData.get(0).
		
		
	}

	
}
